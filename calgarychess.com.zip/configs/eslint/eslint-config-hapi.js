'use strict';
// https://github.com/continuationlabs/eslint-config-hapi
// 12.2.0


module.exports = {

  'env': {
    'node': true,
    'es6': true
  },


  'plugins': [
    '@hapi/eslint-plugin-hapi'
  ],


  'parserOptions': {
    'ecmaVersion': 2019
  },


  rules: {
    '@hapi/hapi/capitalize-modules': ['warn', 'global-scope-only'],
    '@hapi/hapi/for-loop': ['warn', { maxDepth: 3, startIterator: 'i' }],
    '@hapi/hapi/no-var': 'error',
    '@hapi/hapi/scope-start': 'warn',
    '@hapi/hapi/no-arrowception': 'error',
    'camelcase': 'off',
    'consistent-return': 'off',
    'vars-on-top': 'off',
    'new-cap': 'off',
    'no-console': 'off',
    'no-constant-condition': 'error',
    'no-empty': 'off',
    'no-native-reassign': 'off',
    'no-underscore-dangle': 'off',
    'no-undef': ['error', { typeof: false }],
    'no-process-exit': 'off',
    'no-unused-expressions': 'off',
    'no-regex-spaces': 'off',
    'no-catch-shadow': 'off',
    'no-lonely-if': 'off',
    'brace-style': ['warn', 'stroustrup'],
    'no-shadow': ['warn', { allow: ['err', 'done'] }],
    'no-unused-vars': ['warn', { vars: 'all', varsIgnorePattern: '^internals$', args: 'none' }],
    'one-var': ['error', 'never'],
    'handle-callback-err': ['error', '^(e|err|error)$'],
    'array-bracket-spacing': 'warn',
    'dot-notation': 'warn',
    'eol-last': 'warn',
    'no-trailing-spaces': 'warn',
    'no-eq-null': 'warn',
    'no-extend-native': 'warn',
    'no-redeclare': 'warn',
    'no-loop-func': 'warn',
    'yoda': ['warn', 'never'],
    'sort-vars': 'warn',
    'arrow-parens': ['error', 'always'],
    'arrow-spacing': ['error', { before: true, after: true }],
    'quotes': ['error', 'single', { allowTemplateLiterals: true }],
    'consistent-this': ['error', 'self'],
    'new-parens': 'error',
    'no-array-constructor': 'error',
    'no-confusing-arrow': 'error',
    'no-new-object': 'error',
    'no-spaced-func': 'error',
    'no-mixed-spaces-and-tabs': 'error',
    'keyword-spacing': ['error', { before: true, after: true }],
    'semi': ['error', 'always'],
    'semi-spacing': ['error', { before: false, after: true }],
    'space-infix-ops': 'error',
    'space-unary-ops': ['warn', { words: true, nonwords: false }],
    'strict': ['error', 'global'],
    'eqeqeq': 'error',
    'curly': ['error', 'all'],
    'no-eval': 'error',
    'no-else-return': 'error',
    'no-return-assign': 'error',
    'no-new-wrappers': 'error',
    'comma-dangle': ['error', 'never'],
    'no-sparse-arrays': 'error',
    'no-ex-assign': 'error',
    'prefer-arrow-callback': 'error',
    'prefer-const': ['error', { destructuring: 'all' }],
    'indent': ['error', 4, { SwitchCase: 1 }],
    'space-before-function-paren': ['error', { anonymous: 'always', named: 'never' }],
    'func-style': ['error', 'expression'],
    'object-curly-spacing': ['error', 'always'],
    'object-shorthand': ['error', 'properties'],
    'no-unsafe-finally': 'error',
    'no-useless-computed-key': 'error',
    'require-await': 'error',
    'constructor-super': 'error',
    'no-buffer-constructor': 'error',
    'no-mixed-requires': 'error',
    'no-new-require': 'error',
    'no-caller': 'error',
    'no-const-assign': 'error',
    'no-dupe-class-members': 'error',
    'no-class-assign': 'warn',
    'no-new-symbol': 'error',
    'no-this-before-super': 'error',
    'prefer-rest-params': 'error',
    'prefer-spread': 'error',
    'no-useless-call': 'error',
    'rest-spread-spacing': ['error', 'never'],
    'no-extra-semi': 'error',
    'padding-line-between-statements': [
      'error',
      { blankLine: 'always', prev: 'directive', next: '*' },
      { blankLine: 'any', prev: 'directive', next: 'directive' },
      { blankLine: 'always', prev: 'cjs-import', next: '*' },
      { blankLine: 'any', prev: 'cjs-import', next: 'cjs-import' },
      { blankLine: 'always', prev: 'cjs-export', next: '*' },
      { blankLine: 'always', prev: 'multiline-block-like', next: '*' },
      { blankLine: 'always', prev: 'class', next: '*' }
    ]
  }

};
